./tonlib-cuda-cli -V
./tonlib-cuda-cli -v 3 -C global.config.json -e "pminer start Ef-FV4QTxLl-7Ct3E6MqOtMt-RGXMxi27g4I645lw6MTWg0f EQDU86V5wyPrLd4nQ0RHPcCLPZq_y1O5wFWyTsMw63vjXTOv 0 32 0"

